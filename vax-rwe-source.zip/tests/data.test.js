import test from 'node:test';
import assert from 'node:assert/strict';
import * as XLSX from 'xlsx';
import {parseFile,makeTable,checkTable,moduleState,modules,preflight,demoTables,guessModule} from '../src/data.js';

test('demo covers all 11 modules with intended completeness',()=>{
 const tables=demoTables();assert.equal(modules.length,11);
 const states=modules.filter(m=>m.id!=='other').map(m=>moduleState(m,tables).status);
 assert.equal(states.filter(s=>s==='complete').length,6);assert.equal(states.filter(s=>s==='partial').length,2);assert.equal(states.filter(s=>s==='empty').length,2);
 assert.deepEqual(preflight(tables).map(c=>c.name),['有效性研究','安全性研究']);assert.ok(preflight(tables).every(c=>c.ready));
});
test('CSV BOM, Chinese aliases and quoted commas',async()=>{
 const [t]=await parseFile(new File(['\uFEFF患者ID,疫苗名称,接种日期,剂次\nDEMO_1,"疫苗,A",2025-10-12,1\n'], 'test.csv'));
 assert.equal(t.moduleId,'vaccination');assert.equal(t.rows[0]['疫苗名称'],'疫苗,A');assert.equal(moduleState(modules[1],[t]).status,'complete');
});
test('Excel multi-sheet and empty sheet',async()=>{
 const wb=XLSX.utils.book_new();
 XLSX.utils.book_append_sheet(wb,XLSX.utils.json_to_sheet([{patient_id:'DEMO_1',vaccine_name:'流感疫苗',vaccination_date:'2025-10-12',dose:1}]),'vaccines');
 XLSX.utils.book_append_sheet(wb,XLSX.utils.json_to_sheet([{patient_id:'DEMO_1',test_date:'2025-10-12',test_result:'阴性'}]),'labs');
 XLSX.utils.book_append_sheet(wb,XLSX.utils.aoa_to_sheet([]),'empty');
 for(const ext of ['xlsx','xls']){const tables=await parseFile(new File([XLSX.write(wb,{type:'buffer',bookType:ext==='xls'?'biff8':'xlsx'})],`book.${ext}`));assert.equal(tables.length,2);assert.deepEqual(tables.map(t=>t.moduleId),['vaccination','lab']);}
});
test('invalid files return understandable errors',async()=>{
 await assert.rejects(parseFile(new File(['hello'],'a.txt')),/仅支持/);
 await assert.rejects(parseFile(new File(['a,b\n'],'a.csv')),/没有/);
 await assert.rejects(parseFile(new File(['a,b\n1,2,3'],'a.csv')),/结构异常/);
 await assert.rejects(parseFile(new File([' '.repeat(20*1024*1024+1)],'big.csv')),/20 MB/);
});
test('unknown data retained as other',()=>assert.equal(guessModule(['custom_code','note']),'other'));
test('missing key, blank, duplicated and invalid dates flagged',()=>{
 const t=makeTable('bad.csv',[{patient_id:'',vaccine_name:'demo',vaccination_date:'2025-02-30'},{patient_id:'',vaccine_name:'demo',vaccination_date:'2025-02-30'}]);
 const types=checkTable(t).map(x=>x.type);for(const type of ['缺少字段','缺失值','重复记录','无效日期'])assert.ok(types.includes(type));
});
test('hospital dates are checked without changing rows',()=>{
 const t=makeTable('hospital',[{patient_id:'demo',admission_date:'2025-10-20',discharge_date:'2025-10-12'}]);const before=JSON.stringify(t.rows);assert.ok(checkTable(t).some(x=>x.type==='日期逻辑'));assert.equal(JSON.stringify(t.rows),before);
});
test('completeness does not join unrelated partial tables',()=>{
 const a=makeTable('one',[{patient_id:'d',vaccine_name:'demo'}]);a.moduleId='vaccination';a.mapping={patient_id:'patient_id',vaccine_name:'vaccine_name'};
 const b=makeTable('two',[{vaccination_date:'2025-10-12',dose:1}]);b.moduleId='vaccination';b.mapping={vaccination_date:'vaccination_date',dose:'dose'};
 assert.equal(moduleState(modules[1],[a,b]).status,'partial');
});
test('branch preflight ignores optional lab and text but requires exposure dates',()=>{
 const tables=demoTables().filter(t=>!['lab','text'].includes(t.moduleId));
 assert.ok(preflight(tables).every(c=>c.ready));
 tables.find(t=>t.moduleId==='vaccination').mapping.vaccination_date='';
 assert.ok(preflight(tables).every(c=>!c.ready&&c.missing.includes('疫苗接种')));
});
test('branch preflight accepts alternative outcomes and flags missing outcomes',()=>{
 const tables=demoTables().filter(t=>['population','vaccination','hospital'].includes(t.moduleId));
 assert.ok(preflight(tables).every(c=>c.ready));
 assert.ok(preflight(tables.filter(t=>t.moduleId!=='hospital')).every(c=>!c.ready&&c.missing.some(x=>x.includes('结局数据'))));
 assert.ok(preflight([]).every(c=>!c.ready));
});

test('mixed CSV splits into modules without losing columns, rows or source values',async()=>{
 const csv='患者ID,出生日期,性别,随访开始日期,随访结束日期,疫苗名称,接种日期,剂次,ICD编码,诊断日期,备注\nDEMO_1,1955-03-12,女,2025-01-01,2025-12-31,流感疫苗,2025-10-12,1,J10.1,2025-10-20,合成备注\nDEMO_2,1960-04-01,男,2025-01-01,2025-12-31,,,1,,,待核实\n';
 const ts=await parseFile(new File([csv],'mixed.csv'));
 assert.deepEqual(ts.map(t=>t.moduleId),['population','vaccination','diagnosis','other']);
 assert.equal(new Set(ts.map(t=>t.sourceId)).size,1);
 assert.ok(ts.every(t=>t.sourceName==='mixed.csv'&&t.split&&t.count===2&&t.rows[1]['患者ID']==='DEMO_2'));
 assert.deepEqual(new Set(ts.flatMap(t=>t.headers)),new Set(csv.split('\n')[0].split(',')));
 const v=ts.find(t=>t.moduleId==='vaccination');assert.deepEqual(v.headers,['患者ID','疫苗名称','接种日期','剂次']);assert.equal(v.rows[0]['接种日期'],'2025-10-12');
 const other=ts.find(t=>t.moduleId==='other');assert.deepEqual(other.headers,['患者ID','备注']);
 assert.ok(checkTable(v).some(x=>x.type==='缺失值'&&x.row===3));
 assert.equal(moduleState(modules[1],ts).status,'complete');
});
test('mixed Excel sheets split independently and retain source identity',async()=>{
 const wb=XLSX.utils.book_new();
 XLSX.utils.book_append_sheet(wb,XLSX.utils.json_to_sheet([{patient_id:'D1',vaccine_name:'demo',vaccination_date:'2025-10-12',dose:1,icd_code:'J10',diagnosis_date:'2025-10-20'}]),'混合表');
 XLSX.utils.book_append_sheet(wb,XLSX.utils.json_to_sheet([{patient_id:'D1',test_date:'2025-10-20',test_result:'阴性'}]),'检验表');
 const ts=await parseFile(new File([XLSX.write(wb,{type:'buffer',bookType:'xlsx'})],'mixed.xlsx'));
 assert.deepEqual(ts.map(t=>t.moduleId),['vaccination','diagnosis','lab']);assert.equal(new Set(ts.map(t=>t.sourceId)).size,2);
 assert.equal(ts[0].sourceName,'mixed.xlsx · 混合表');assert.equal(ts[2].split,false);
});
test('shared encounter ID links diagnosis without inventing an encounter module',async()=>{
 const ts=await parseFile(new File(['patient_id,encounter_id,icd_code,diagnosis_date,test_date,test_result\nD1,E1,J10,2025-10-20,2025-10-20,阴性'],'linked.csv'));
 assert.deepEqual(ts.map(t=>t.moduleId),['diagnosis','lab']);assert.ok(ts.every(t=>t.headers.includes('encounter_id')));
});
test('ID-only and unknown-only tables remain other; missing ID is not fabricated',async()=>{
 for(const csv of ['patient_id,note\nD1,unknown','patient_id,encounter_id\nD1,E1']){const ts=await parseFile(new File([csv],'other.csv'));assert.equal(ts.length,1);assert.equal(ts[0].moduleId,'other');}
 const ts=await parseFile(new File(['vaccine_name,diagnosis_date\ndemo,2025-10-20'],'missing-id.csv'));assert.equal(ts.length,2);assert.ok(ts.every(t=>checkTable(t).some(x=>x.field==='patient_id'&&x.type==='缺少字段')));
});
