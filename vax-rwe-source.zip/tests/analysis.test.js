import test from 'node:test';
import assert from 'node:assert/strict';
import {parseFile,demoTables} from '../src/data.js';
import {summarizeData,profileField,answerDataQuestion} from '../src/analysis.js';
test('split projections do not inflate source rows or unique population IDs',async()=>{
 const ts=await parseFile(new File(['患者ID,性别,疫苗名称,接种日期,剂次,备注\nD1,女,合成疫苗A,2025-10-12,1,一\nD1,女,合成疫苗B,2025-02-30,,二\nD2,男,合成疫苗A,,1,三'],'mix.csv'));
 const s=summarizeData(ts);assert.equal(s.sourceCount,1);assert.equal(s.sourceRows,3);assert.equal(s.subjectCount,2);assert.deepEqual(s.vaccines[0],{label:'合成疫苗A',count:2});assert.equal(s.invalidDateCount,2);assert.deepEqual(s.monthly,[{label:'2025-10',count:1}]);assert.ok(s.missingCells>0);
 assert.deepEqual(profileField(ts.find(t=>t.moduleId==='other'),'备注').map(x=>x.count),[1,1,1]);
});
test('empty data and demo counts are represented honestly',()=>{
 const empty=summarizeData([]);assert.equal(empty.missingRate,null);assert.equal(empty.hasPopulation,false);assert.deepEqual(empty.vaccines,[]);
 const demo=summarizeData(demoTables());assert.equal(demo.sourceRows,45);assert.equal(demo.subjectCount,5);assert.equal(demo.vaccines[0].count,5);
});
test('local answers use actual summary and refuse clinical effect claims',()=>{
 const s=summarizeData(demoTables());assert.match(answerDataQuestion('数据概况',s),/45 行/);assert.match(answerDataQuestion('性别分布',s),/未按患者去重/);assert.match(answerDataQuestion('疫苗有效性是多少',s),/不能据此判断/);assert.match(answerDataQuestion('哪种疫苗更安全',s),/不能据此判断/);assert.match(answerDataQuestion('随便聊聊',s),/尚未接入 AI/);
});
