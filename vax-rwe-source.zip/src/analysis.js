import {modules,checkTable} from './data.js';
const empty=v=>v===null||v===undefined||String(v).trim()==='';
const countValues=values=>{
 const counts=new Map();for(const v of values){const key=empty(v)?'未填写':String(v).trim();counts.set(key,(counts.get(key)||0)+1);}
 return [...counts].map(([label,count])=>({label,count})).sort((a,b)=>b.count-a.count||a.label.localeCompare(b.label));
};
function values(tables,moduleId,field){return tables.filter(t=>t.moduleId===moduleId&&t.mapping[field]).flatMap(t=>t.rows.map(r=>r[t.mapping[field]]));}
export function summarizeData(tables){
 const sources=[...new Map(tables.map(t=>[t.sourceId||t.id,t])).values()];
 const ids=values(tables,'population','patient_id');
 let missingCells=0,totalCells=0;
 for(const t of tables){const fields=modules.find(m=>m.id===t.moduleId).fields;for(const row of t.rows)for(const f of fields){totalCells++;if(!t.mapping[f]||empty(row[t.mapping[f]]))missingCells++;}}
 const dates=values(tables,'vaccination','vaccination_date').map(v=>String(v??'').trim()).filter(v=>/^\d{4}-\d{2}-\d{2}$/.test(v)&&Number.isFinite(Date.parse(v+'T00:00:00Z'))&&new Date(v+'T00:00:00Z').toISOString().slice(0,10)===v);
 return {sourceCount:sources.length,sourceRows:sources.reduce((n,t)=>n+t.rows.length,0),subjectCount:new Set(ids.filter(v=>!empty(v)).map(v=>String(v).trim())).size,hasPopulation:tables.some(t=>t.moduleId==='population'&&t.mapping.patient_id),missingCells,totalCells,missingRate:totalCells?missingCells/totalCells:null,issueCount:tables.reduce((n,t)=>n+checkTable(t).length,0),modules:modules.map(m=>({label:m.name,count:tables.filter(t=>t.moduleId===m.id).reduce((n,t)=>n+t.rows.length,0)})).filter(m=>m.count),vaccines:countValues(values(tables,'vaccination','vaccine_name')),sex:countValues(values(tables,'population','sex')),diagnoses:countValues(values(tables,'diagnosis','icd_code')),monthly:countValues(dates.map(v=>v.slice(0,7))).sort((a,b)=>a.label.localeCompare(b.label)),yearly:countValues(dates.map(v=>v.slice(0,4))).sort((a,b)=>a.label.localeCompare(b.label)),invalidDateCount:values(tables,'vaccination','vaccination_date').length-dates.length};
}
export function profileField(table,field){return table&&table.headers.includes(field)?countValues(table.rows.map(r=>r[field])):[];}
const topText=items=>items.length?items.slice(0,10).map(x=>`${x.label}：${x.count} 条`).join('；'):'当前无可用记录或字段未映射';
export function answerDataQuestion(question,summary){
 const q=question.trim();
 if(/因果|风险升高|不良反应率|发生率|保护率|有效率|有效性|安全性|安全信号|是否安全|哪.*安全|更安全|比较.*疫苗/.test(q))return '当前仅支持导入数据的描述性统计，不能据此判断疫苗有效性、安全性或因果关系。请通过“选择研究方向”配置研究；当前尚未运行统计模型或安全信号检测。';
 if(/性别|男女|男性|女性/.test(q))return '人口学性别记录分布：'+topText(summary.sex)+'。按记录计数，未按患者去重。';
 if(/疫苗|接种种类|接种类型/.test(q))return '疫苗接种记录分布：'+topText(summary.vaccines)+'。按记录计数，不代表接种人数。';
 if(/时间|趋势|年份|年度|月份|月度/.test(q))return '接种记录按月分布：'+topText(summary.monthly)+`。另有 ${summary.invalidDateCount} 条接种日期为空或格式无效，未计入趋势。`;
 if(/诊断|疾病|ICD|icd/.test(q))return '诊断编码记录分布：'+topText(summary.diagnoses)+'。编码的临床含义仍需数据字典确认。';
 if(/缺失|完整|质量|异常|检查/.test(q))return summary.totalCells?`关键字段空缺 ${summary.missingCells} / ${summary.totalCells} 个单元格（${(summary.missingRate*100).toFixed(1)}%），包含未映射的关键列。当前基础检查共 ${summary.issueCount} 项问题，可到“字段检查”复核。`:'当前没有可检查的标准模块记录，请先导入数据并完成字段映射。';
 if(/多少|概览|概况|数据|记录|人数|对象/.test(q))return `当前共有 ${summary.sourceCount} 张源表、${summary.sourceRows} 行可读取样本；源表行数不因模块拆分重复相加。`+(summary.hasPopulation?`人口学中非空患者 ID 去重后有 ${summary.subjectCount} 个。`:'尚无人口学模块，无法统计研究对象数。');
 return '当前为本地规则问答，尚未接入 AI。可以询问：数据概况、疫苗记录分布、性别分布、接种时间趋势、诊断编码和字段缺失情况。';
}
