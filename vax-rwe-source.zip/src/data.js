import Papa from 'papaparse';
import * as XLSX from 'xlsx';

// 原文档的 11 个模块；字段是 Demo 最小配置，可在此替换正式数据字典。
export const modules = [
 ['population','人口学','共用','居民基础信息与观察期',['patient_id','birth_date','sex','followup_start','followup_end']],
 ['vaccination','疫苗接种','共用','疫苗暴露、剂次与接种时间',['patient_id','vaccine_name','vaccination_date','dose']],
 ['encounter','就诊 / 随访','共用','门急诊及纵向随访记录',['patient_id','encounter_id','visit_date']],
 ['diagnosis','诊断','共用','疾病编码与结局识别',['patient_id','icd_code','diagnosis_date']],
 ['hospital','住院','共用','住院、出院及严重结局',['patient_id','admission_date','discharge_date']],
 ['death','死亡','共用','死亡时间与死因登记',['patient_id','death_date']],
 ['medication','处方 / 用药','共用','处方及合并用药信息',['patient_id','drug_name','prescription_date']],
 ['lab','检验检查','有效性侧重','病原检测与实验室确诊',['patient_id','test_date','test_result']],
 ['text','病历文本','安全性侧重','主诉、现病史与出院小结',['patient_id','record_date','clinical_text']],
 ['history','既往史 / 危险因素','安全性侧重','既往病史、过敏与危险因素',['patient_id','history_name','onset_date']],
 ['other','其他','待归类','免疫规划、AEFI、妇幼与体检等',[]],
].map(([id,name,focus,description,fields])=>({id,name,focus,description,fields}));
export const aliases = {
 patient_id:['患者ID','患者id','居民ID','脱敏患者ID','个人编号'],birth_date:['出生日期'],sex:['性别'],followup_start:['随访开始日期','随访起始日期'],followup_end:['随访结束日期'],
 vaccine_name:['疫苗名称','疫苗种类'],vaccination_date:['接种日期'],dose:['剂次'],encounter_id:['就诊ID','就诊号'],visit_date:['就诊日期','随访日期'],icd_code:['ICD编码','诊断编码'],diagnosis_date:['诊断日期'],admission_date:['入院日期'],discharge_date:['出院日期'],death_date:['死亡日期'],drug_name:['药品名称'],prescription_date:['处方日期'],test_date:['检测日期'],test_result:['检测结果'],record_date:['记录日期'],clinical_text:['病历文本','主诉'],history_name:['既往病史','病史名称'],onset_date:['发生日期','发病日期']
};
export function matchField(headers,field){return headers.find(h=>h.trim().toLowerCase()===field || (aliases[field]||[]).includes(h.trim()))||'';}
export function guessModule(headers){let best='other',score=0; for(const m of modules.filter(m=>m.id!=='other')){const hits=m.fields.filter(f=>f!=='patient_id'&&matchField(headers,f)).length; if(hits>score){best=m.id;score=hits;}}return best;}
export function makeTable(name,rows){const headers=Object.keys(rows[0]||{}); const moduleId=guessModule(headers); const m=modules.find(m=>m.id===moduleId);return {id:crypto.randomUUID(),name,rows,headers,count:rows.length,moduleId,mapping:Object.fromEntries(m.fields.map(f=>[f,matchField(headers,f)])),demo:false};}
// 按列拆分，保留原行顺序及空值；公共关联键不单独触发一个模块。
export function splitTable(table){
 const {headers,rows}=table;
 const patientKeys=headers.filter(h=>matchField([h],'patient_id'));
 const encounterKeys=headers.filter(h=>matchField([h],'encounter_id'));
 const matched=modules.filter(m=>m.id!=='other'&&m.fields.some(f=>!['patient_id','encounter_id'].includes(f)&&matchField(headers,f)));
 const used=new Set();
 const parts=matched.map(m=>{
  const columns=headers.filter(h=>patientKeys.includes(h)||m.fields.some(f=>matchField([h],f))||(['encounter','diagnosis','lab','text','hospital'].includes(m.id)&&encounterKeys.includes(h)));
  columns.forEach(h=>used.add(h));return {module:m,columns};
 });
 const unknown=headers.filter(h=>!used.has(h));
 if(unknown.length)parts.push({module:modules.find(m=>m.id==='other'),columns:headers.filter(h=>unknown.includes(h)||patientKeys.includes(h)||encounterKeys.includes(h))});
 return parts.map(({module:m,columns})=>({
  ...table,id:crypto.randomUUID(),name:parts.length>1?`${table.name} → ${m.name}`:table.name,
  sourceId:table.id,sourceName:table.name,sourceRowCount:table.count,sourceHeaders:headers,split:parts.length>1,
  moduleId:m.id,headers:columns,rows:rows.map(r=>Object.fromEntries(columns.map(h=>[h,r[h]]))),
  mapping:Object.fromEntries(m.fields.map(f=>[f,matchField(columns,f)]))
 }));
}
export async function parseFile(file){
 const ext=file.name.split('.').pop().toLowerCase();
 if(!['csv','xlsx','xls'].includes(ext))throw Error('仅支持 CSV、XLSX 或 XLS 文件');
 if(file.size>20*1024*1024)throw Error('演示版单个文件上限为 20 MB');
 let tables=[];
 if(ext==='csv'){
  const raw=await file.text();const parsed=Papa.parse(raw.replace(/^\uFEFF/,''),{header:true,skipEmptyLines:'greedy',transformHeader:h=>h.trim()});
  if(parsed.errors.length)throw Error('CSV 结构异常：'+parsed.errors[0].message);
  if(!parsed.data.length)throw Error('文件没有可读取的数据行');
  tables=[makeTable(file.name,parsed.data)];
 }else{
  const book=XLSX.read(await file.arrayBuffer(),{type:'array',cellDates:true});
  tables=book.SheetNames.map(s=>makeTable(file.name+' · '+s,XLSX.utils.sheet_to_json(book.Sheets[s],{defval:'',raw:false,dateNF:'yyyy-mm-dd'}))).filter(t=>t.count);
 }
 if(!tables.length)throw Error('工作簿没有可读取的数据行');
 if(tables.some(t=>t.headers.some(h=>!h||/^__EMPTY/.test(h))))throw Error('请为每一列填写唯一的表头名称');
 return tables.flatMap(splitTable);
}
export function moduleState(m,tables){
 const ts=tables.filter(t=>t.moduleId===m.id);
 if(m.id==='other')return {status:ts.length?'other':'empty',tables:ts,missing:[],count:ts.reduce((n,t)=>n+t.count,0)};
 // 不跨表拼接字段：至少一张表要具备完整关键字段。
 const missing=ts.length?ts.map(t=>m.fields.filter(f=>!t.mapping[f])).sort((a,b)=>a.length-b.length)[0]:m.fields;
 return {status:!ts.length?'empty':missing.length?'partial':'complete',tables:ts,missing,count:ts.reduce((n,t)=>n+t.count,0)};
}
export function checkTable(t){
 const issues=[];const missing=modules.find(m=>m.id===t.moduleId).fields.filter(f=>!t.mapping[f]);
 missing.forEach(f=>issues.push({type:'缺少字段',field:f,row:'—',message:'未映射关键字段'}));
 const seen=new Set();
 t.rows.forEach((r,i)=>{
  const key=JSON.stringify(r);if(seen.has(key))issues.push({type:'重复记录',field:'整行',row:i+2,message:'与前序记录完全相同，未自动删除'});seen.add(key);
  for(const [field,col] of Object.entries(t.mapping))if(col){const v=r[col];if(v===undefined||v===null||String(v).trim()==='')issues.push({type:'缺失值',field,row:i+2,message:'关键字段为空'});else if(/date|start|end/.test(field)&&!/^\d{4}-\d{2}-\d{2}$/.test(String(v)))issues.push({type:'日期格式',field,row:i+2,message:'期望 YYYY-MM-DD'});else if(/date|start|end/.test(field)){const d=new Date(v+'T00:00:00Z');if(!Number.isFinite(+d)||d.toISOString().slice(0,10)!==v)issues.push({type:'无效日期',field,row:i+2,message:'日期不存在'});}}
  const start=r[t.mapping.admission_date],end=r[t.mapping.discharge_date];if(start&&end&&String(start)>String(end))issues.push({type:'日期逻辑',field:'discharge_date',row:i+2,message:'出院日期早于入院日期'});
 });return issues;
}
const counts={population:24860,vaccination:39217,encounter:68214,diagnosis:52309,hospital:4218,medication:18762,lab:6804,history:3210,other:1480};
export function demoTables(){return modules.filter(m=>counts[m.id]).map((m,i)=>{
 let headers=m.fields.filter(f=>!(m.id==='lab'&&f==='test_result')&&!(m.id==='history'&&f==='onset_date'));
 if(m.id==='other')headers=['resident_code','reaction_name','report_time'];
 const rows=Array.from({length:5},(_,j)=>Object.fromEntries(headers.map(f=>[f,f==='patient_id'?`DEMO_${String(j+1).padStart(4,'0')}`:f==='sex'?(j%2?'女':'男'):f==='birth_date'?`19${55+j}-03-12`:/date|start|end/.test(f)?(f==='discharge_date'?'2025-10-20':'2025-10-12'):f==='dose'?1:f==='vaccine_name'?'流感疫苗':f==='icd_code'?'J10.1':f==='drug_name'?'合成用药 A':f==='history_name'?'高血压':`演示_${j+1}`])));
 return {id:`demo-${i}`,name:m.id==='other'?'AEFI_登记与体检.xlsx':`${m.id}_2025.csv`,headers,rows,count:counts[m.id],moduleId:m.id,mapping:Object.fromEntries(m.fields.map(f=>[f,matchField(headers,f)])),demo:true};
});}
export function preflight(tables){
 const ok=id=>moduleState(modules.find(m=>m.id===id),tables).status==='complete';
 return [
  {id:'effectiveness',name:'有效性研究',question:'疫苗是否降低目标疾病的发生？',detail:'研究对象、接种暴露、观察时间及目标疾病结局来源',outcomes:['diagnosis','lab','hospital']},
  {id:'safety',name:'安全性研究',question:'接种后是否存在健康事件风险升高？',detail:'研究对象、接种时间、观察时间及候选健康事件来源',outcomes:['diagnosis','hospital','death']}
 ].map(p=>{
  const missing=['population','vaccination'].filter(id=>!ok(id)).map(id=>modules.find(m=>m.id===id).name);
  if(!p.outcomes.some(ok))missing.push('结局数据（'+p.outcomes.map(id=>modules.find(m=>m.id===id).name).join(' / ')+'，至少一项）');
  return {...p,ready:missing.length===0,missing};
 });
}
export function download(name,content,type='text/plain;charset=utf-8'){const url=URL.createObjectURL(new Blob([content],{type}));const a=document.createElement('a');a.href=url;a.download=name;a.click();setTimeout(()=>URL.revokeObjectURL(url),1000);}
