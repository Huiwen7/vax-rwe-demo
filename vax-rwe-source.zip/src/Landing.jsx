import { platformLogo } from "./brand.js";
import React,{useRef,useState} from 'react';
import {Activity,ArrowRight,ArrowUpRight,UploadCloud,ShieldCheck,Play,Plus} from 'lucide-react';
import './landing.css';

export default function Landing({onImport,onFiles,onDemo,onContinue,hasData,busy}){
 const entry=useRef(null),[drag,setDrag]=useState(false);
 function start(){entry.current?.scrollIntoView({behavior:window.matchMedia('(prefers-reduced-motion: reduce)').matches?'auto':'smooth',block:'center'});entry.current?.querySelector('button')?.focus({preventScroll:true});}
 return <div className="welcome-page">
  <header className="welcome-header"><a href="#" className="welcome-logo" aria-label="VaxRWE 首页"><img src={platformLogo} alt="VaxRWE" className="platform-logo"/></a><div className="welcome-header-actions"><button className="welcome-demo" onClick={onDemo}><Play size={12}/>体验演示</button><button className="welcome-top-cta" onClick={hasData?onContinue:start}>{hasData?'返回工作台':'开始研究'}<ArrowUpRight size={15}/></button></div></header>
  <section className="welcome-hero"><div className="welcome-copy"><p className="welcome-kicker"><span/>疫苗真实世界研究平台</p><h1>让数据，<br/>成为<span>证据。</span></h1>
   <section className="welcome-entry" ref={entry} aria-label="开始研究"><div className="entry-heading"><h2>数据导入</h2><span>01 / 导入数据</span></div><button aria-label="导入数据" className={`entry-zone ${drag?'drag':''}`} disabled={busy} onClick={onImport} onDragOver={e=>{e.preventDefault();setDrag(true)}} onDragLeave={()=>setDrag(false)} onDrop={e=>{e.preventDefault();setDrag(false);if(!busy)onFiles(e.dataTransfer.files);}}><span className="entry-icon"><UploadCloud size={25}/></span><span><b>{busy?'正在读取…':'导入数据'}</b><small>选择或拖入 CSV / Excel 文件</small></span><Plus size={20}/></button><div className="entry-bottom"><span>自动识别 · 模块拆分</span><button onClick={onDemo}>先看看演示<ArrowRight size={13}/></button></div></section>
   <p className="welcome-privacy"><ShieldCheck size={12}/>浏览器内处理</p>
  </div>
  <div className="research-scene" aria-label="数据导入后分为有效性和安全性研究两条主线的动态示意"><div className="scene-grid"/><div className="scene-orbit orbit-one"/><div className="scene-orbit orbit-two"/><div className="scene-topline"><span><i/>RESEARCH IN MOTION</span><span>01 → 02</span></div><svg className="scene-paths" viewBox="0 0 520 460" aria-hidden="true"><path d="M260 159 V218 Q260 240 164 240 Q130 240 130 272 V292"/><path d="M260 159 V218 Q260 240 356 240 Q390 240 390 272 V292"/><circle r="4"><animateMotion dur="4s" repeatCount="indefinite" path="M260 159 V218 Q260 240 164 240 Q130 240 130 272 V292"/></circle><circle r="4"><animateMotion dur="4s" begin="1s" repeatCount="indefinite" path="M260 159 V218 Q260 240 356 240 Q390 240 390 272 V292"/></circle></svg><div className="scene-source"><span className="scene-file"><UploadCloud size={24}/></span><div><b>导入数据</b><small>CSV / Excel · 自动模块拆分</small></div><span className="scene-check"><ShieldCheck size={17}/></span></div><div className="scene-branch efficacy"><span className="branch-symbol"><Activity size={20}/></span><small>EFFECTIVENESS</small><h3>有效性研究</h3><svg viewBox="0 0 160 45" aria-hidden="true"><path d="M0 9 C20 7 25 15 40 15 S60 25 80 23 S100 35 120 33 S140 39 160 39"/></svg></div><div className="scene-branch safety"><span className="branch-symbol"><ShieldCheck size={20}/></span><small>SAFETY</small><h3>安全性研究</h3><svg viewBox="0 0 160 45" aria-hidden="true"><path d="M0 33 L22 33 L31 29 L40 35 L57 32 L65 12 L75 37 L88 29 L106 32 L125 28 L140 32 L160 30"/></svg></div><div className="scene-bottom"><span>示意动画 · 非真实研究结果</span><span>VaxRWE / 01</span></div></div>
  </section>
  <footer className="welcome-footer"><span>VaxRWE</span><span>演示环境 <i/> 有效性 & 安全性</span></footer>
 </div>
}
